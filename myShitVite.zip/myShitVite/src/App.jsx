import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {

  return (
    <>
    <div className="holder">
      <div className="header">
        <h2>Product List</h2>
        <div>add product</div>
      </div>
      <div className="searchBar"></div>
      <div className="cardHolder">
        <div className="card">
          <div className="face"></div>
        </div>
      </div>
    </div>
    </>
  )
}

export default App
